#ifndef COLOR_H
#define COLOR_H

class Color {
public:
    float r;
    float g;
    float b;
    float a;

    Color() {
        this->r = 0;
        this->g = 0;
        this->b = 0;
        this->a = 0;
    }

    Color(float r, float g, float b, float a) {
        this->r = r;
        this->g = g;
        this->b = b;
        this->a = a;
    }

    Color(float r, float g, float b) {
        this->r = r;
        this->g = g;
        this->b = b;
        this->a = 225;
    }

    static Color Clear(){
        return Color(0, 0, 0, 0);
    }

    static Color Black(){
        return Color(0, 0, 0);
    }

    static Color White(){
        return Color(255, 255, 255);
    }

    static Color Red(){
        return Color(255, 0, 0);
    }

    static Color Yellow(){
        return Color(255, 255, 0,250);
    }

    static Color Green(){
        return Color(0, 255, 0,200);
    }

    static Color Yellow4(){
        return Color(255, 145, 0,170);
    }

    static Color Green4(){
        return Color(0, 210, 0,170);
    }

    static Color Orange1(){
        return Color(255, 155, 50,53);
    }

    static Color Green1(){
        return Color(0, 220,0 ,150);
    }

    static Color Orange2(){
        return Color(255, 155, 60,52);
    }

    static Color Green2(){
        return Color(0, 255, 0,100);
    }

    static Color Orange3(){
        return Color(255, 255, 0,51);
    }
    static Color Orange(){
        return Color(255, 155, 0,255);
    }
    static Color Green3(){
        return Color(0, 255, 0, 50);
    }

    static Color Cyan(){
        return Color(0, 255, 255);
    }

    static Color Blue(){
        return Color(0, 0, 255);
    }

    static Color Purple(){
        return Color(128, 0, 128);
    }

    static Color Maroon(){
        return Color(128, 0, 0);
    }
};

#endif
