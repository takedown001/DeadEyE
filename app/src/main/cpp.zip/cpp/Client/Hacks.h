#ifndef HACKS_H
#define HACKS_H

#include "kmods.h"
bool isValidPlayer(PlayerData data){
    return (data.Body != Vector2::Zero() && data.Head != Vector2::Zero());
}

bool isValidItem(ItemData data){
    return (data.Location != Vector2::Zero());
}

/*int isOutsideSafezone(Vector2 pos, Vector2 screen) {
    Vector2 mSafezoneTopLeft(screen.x * 0.04f, screen.y * 0.04f);
    Vector2 mSafezoneBottomRight(screen.x * 0.96f, screen.y * 0.96f);

    int result = 0;
    if (pos.y < mSafezoneTopLeft.y) {
        // top
        result |= 1;
    }
    if (pos.x > mSafezoneBottomRight.x) {
        // right
        result |= 2;
    }
    if (pos.y > mSafezoneBottomRight.y) {
        // bottom
        result |= 4;
    }
    if (pos.x < mSafezoneTopLeft.x) {
        // left
        result |= 8;
    }
    return result;
}*/

Vector2 pushToScreenBorder(Vector2 Pos, Vector2 screen, int offset) {
    int x = (int)Pos.x;
    int y = (int)Pos.y;
    if (Pos.y < 0) {
        // top
        y = -offset;
    }
    if (Pos.x > screen.x) {
        // right
        x = (int)screen.x + offset;
    }
    if (Pos.y > screen.y) {
        // bottom
        y = (int)screen.y + offset;
    }
    if (Pos.x < 0) {
        // left
        x = -offset;
    }
    return Vector2(x, y);
}

bool isOutsideSafeZone(Vector2 pos, Vector2 screen) {
    if (pos.y < 0) {
        return true;
    }
    if (pos.x > screen.x) {
        return true;
    }
    if (pos.y > screen.y) {
        return true;
    }
    return pos.x < 0;
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    if(isESP){
        esp.DrawCrosshair(Color(0, 0, 0, 255), Vector2(screenWidth / 2, screenHeight / 2), 42);
        if(isfov){
            esp.DrawCircle(Color(255, 0, 0, 200),2,Vector2(screenWidth / 2, screenHeight / 2),130);
        }
        Vector2 screen(screenWidth, screenHeight);
        float mScale = screenHeight / (float) 1080;
        if(isfree){
        esp.DrawText(Color::Red(), "Deadeye.Gcc-org.com", Vector2(
                (screenWidth) - 130, (screenHeight) - 60), 20);
        esp.DrawText(Color::Red(), "@DeadEye_TG", Vector2(
                 155,(screenHeight) - 60 ), 20);
            }
        esp.DrawText(Color::Red(), "Deadeye.Gcc-org.com", Vector2(
                (screenWidth) - 130, (screenHeight) - 60), 20);
        Response response = getData(screenWidth, screenHeight);
        if(response.Success){
            if(isNearEnemy) {
                Color color =  Color::Black();
                Color bg = (response.NearEnemy > 0) ? Color::Yellow4() : Color::Green4();
                string enemyData ;
                Color bg1 = (response.NearEnemy > 0) ? Color::Orange1() : Color::Green1();
                Color bg2 = (response.NearEnemy > 0) ? Color::Orange2() : Color::Green2();
                Color bg3 = (response.NearEnemy > 0) ? Color::Orange3() : Color::Green3();
                if(response.NearEnemy == 0){
                enemyData = "CLEAR";

                } else
                {
                    enemyData = to_string(response.NearEnemy);
                }
                int boxWidth = 140;
                int boxHeight = 40;
                int booxWidth = 160;
                int boooxWidth = 190;
                int booooxWidth = 220;

                esp.DrawFilledRect(bg3,Rect((screenWidth / 2) - (booooxWidth / 2), 77, booooxWidth, boxHeight));//transp
                esp.DrawFilledRect(bg2,Rect((screenWidth / 2) - (boooxWidth / 2), 77, boooxWidth, boxHeight));//transp
                esp.DrawFilledRect(bg1,Rect((screenWidth / 2) - (booxWidth / 2), 77, booxWidth, boxHeight));//transp
                esp.DrawFilledRect(bg,Rect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));//solid
                esp.DrawText(color, enemyData.c_str(), Vector2((screenWidth / 2), 108), 21);
            }

            int count = response.PlayerCount;
            if(count > 0){
                for(int i=0; i < count; i++) {
                    PlayerData player = response.Players[i];
                    if (!isValidPlayer(player)) { continue; }

                    bool isTeamMate = player.TeamID == response.MyTeamID;
                    if (isTeamMate && !isTeamMateShow) { continue; }

                    Vector2 location = player.Body;
                    if (isPlayer360 && isOutsideSafeZone(location, screen)) {
                        string dist;
                        dist += to_string((int) player.Distance);
                        dist += "M";

                        Vector2 hintDotRenderPos = pushToScreenBorder(location, screen,
                                                                        (int) ((mScale * 100) / 3));
                        Vector2 hintTextRenderPos = pushToScreenBorder(location, screen,
                                                                         -(int) ((mScale * 36)));
                        esp.DrawFilledCircle(
                                (isTeamMate ? Color(0, 255, 0, 128) : Color(255, 0, 0, 128)),
                                hintDotRenderPos, (mScale * 100));
                        esp.DrawText(Color::White(), dist.c_str(), hintTextRenderPos,
                                     playerTextSize);
                        continue;
                    }

                    float boxHeight = fabsf(player.Root.y - player.Head.y);
                    float boxWidth = boxHeight * 0.56;
                    Rect Box(player.Head.x - (boxWidth / 2), player.Head.y, boxWidth, boxHeight);

                    if (isPlayerSkel) {
                        esp.DrawCircle(Color::Red(), 4, player.Neck, boxWidth / 6);

                        esp.DrawLine(Color::Red(), 3, player.Neck, player.Chest);
                        esp.DrawLine(Color::Red(), 3, player.Chest, player.Pelvis);

                        esp.DrawLine(Color::Red(), 3, player.Chest, player.LShoulder);
                        esp.DrawLine(Color::Red(), 3, player.Chest, player.RShoulder);

                        esp.DrawLine(Color::Red(), 3, player.LShoulder, player.LElbow);
                        esp.DrawLine(Color::Red(), 3, player.RShoulder, player.RElbow);

                        esp.DrawLine(Color::Red(), 3, player.LElbow, player.LWrist);
                        esp.DrawLine(Color::Red(), 3, player.RElbow, player.RWrist);

                        esp.DrawLine(Color::Red(), 3, player.Pelvis, player.LThigh);
                        esp.DrawLine(Color::Red(), 3, player.Pelvis, player.RThigh);

                        esp.DrawLine(Color::Red(), 3, player.LThigh, player.LKnee);
                        esp.DrawLine(Color::Red(), 3, player.RThigh, player.RKnee);

                        esp.DrawLine(Color::Red(), 3, player.LKnee, player.LAnkle);
                        esp.DrawLine(Color::Red(), 3, player.RKnee, player.RAnkle);
                    }

                    if (isPlayerLine) {
                        if (player.isBot) {
                            esp.DrawLine((isTeamMate ? Color(0, 255, 0) : Color(0, 255, 0)), 1,
                                         Vector2((screenWidth / 2) - (boxWidth / 2), 77 + 40),
                                         player.Neck);
                        } else {
                            esp.DrawLine((isTeamMate ? Color(0, 255, 0) : Color(255, 0, 0)), 1,
                                         Vector2((screenWidth / 2) - (boxWidth / 2), 77 + 40),
                                         player.Neck);
                        }
                    }
                    if (isPlayerBox) {
                        if (player.isBot) {
                            esp.DrawRect((isTeamMate ? Color(0, 255, 0) : Color(0, 255, 0)), 1,
                                         Box);
                        } else {

                            esp.DrawRect((isTeamMate ? Color(0, 255, 0) : Color::White()), 1,
                                         Box);
                        }
                    }
                    if (isPlayerHealth) {
                        if (!isfree) {
                            esp.DrawHorizontalHealthBar(
                                    Vector2(Box.x + (Box.width / 2) - 40, Box.y - 20),
                                    (100 * mScale),
                                    100, player.Health);
                        } else {
                            esp.DrawHorizontalHealthBarFree(
                                    Vector2(Box.x - (35 * mScale), Box.y - 33),
                                    (80 * mScale),
                                    100, player.Health);
                        }
                    }

                    if(isPlayerName) {
                        wstring pname = player.PlayerName;
                        wstring bname = L" AI ";


                        if(player.isBot) {
                            esp.DrawPlayerText(Color::White(), bname.c_str(),
                                               Vector2(Box.x + (Box.width / 2), Box.y - 20),
                                               ((30 * mScale)) / 2);
                        }else{
                            esp.DrawPlayerText(Color::White(), pname.c_str(),
                                               Vector2(Box.x + (Box.width / 2)+22, Box.y - 20),
                                               ((30 * mScale)) / 2);

                        }
                    }
                    if(!isfree) {
                        if (isteamid) {
                            wstring teamid = L"" + to_wstring(player.TeamID);
                            esp.DrawPlayerText(Color::Orange(), teamid.c_str(),
                                               Vector2(Box.x + (Box.width / 2) - 45, Box.y - 20),
                                               ((30 * mScale)) / 2);
                        }
                    }
                    if(isPlayerDist) {
                        string dist;
                        dist += to_string((int) player.Distance);
                        dist += " m";

                        esp.DrawText(Color::Orange(), dist.c_str(),
                                     Vector2(Box.x + (Box.width / 2),
                                             Box.y + Box.height + 25), playerTextSize);
                    }


                }
            }

            count = response.ItemsCount;
            if(count > 0){
                for(int i=0; i < count; i++){
                    ItemData item = response.Items[i];
                    if(!isValidItem(item)){ continue;}

                    if(item.isVehicle && !isVehicle){
                        continue;
                    } else if(item.isLootBox && !isLootBox){
                        continue;
                    } else if(item.isAirDrop && !isAirDrop){
                        continue;
                    } else if(item.isLootItem && !isLootItems){
                        continue;
                    }

                    Vector2 location = item.Location;

                    string dist;
                    dist += "( ";
                    dist += to_string((int) item.Distance);
                    dist += "M";
                    dist += " )";

                    if(isItemName) {
                        esp.DrawText(Color::Orange(), item.Name, Vector2(
                                location.x, location.y + (20 * mScale)), itemTextSize);
                    }
                    if(isItemDist) {
                        esp.DrawText(Color::Green(), dist.c_str(), Vector2(
                                location.x, location.y + (40 * mScale)), itemTextSize);
                    }
                }
            }
        }
    }
}
#endif //HACKS_H
