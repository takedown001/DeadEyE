#include "kmods.h"
#include <ESP.h>
#include <SocketClient.h>
#include "Hacks.h"

using namespace std;

SocketClient client;
ESP espOverlay;

int startClient(){
    client = SocketClient();
    if(!client.Create()){
        LOGE("CE:1");
        return -1;
    }
    if(!client.Connect()){
        LOGE("CE:2");
        return -1;
    }
    if(!initServer()){
        LOGE("CE:3");
        return -1;
    }
    return 0;
}

bool isConnected(){
    return client.connected;
}

void stopClient(){
    if(client.created && isConnected()){
        stopServer();
        client.Close();
    }
}

bool initServer(){
    Request request{InitMode, 0, 0};
    int code = client.send((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response.Success;
        }
    }
    return false;
}

bool stopServer(){
    Request request{StopMode, 0, 0};
    int code = client.send((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response.Success;
        }
    }
    return false;
}

Response getData(int screenWidth, int screenHeight){
    Request request{ESPMode, screenWidth, screenHeight};
    int code = client.send((void*) &request, sizeof(request));
    if(code > 0){
        Response response{};
        size_t length = client.receive((void*) &response);
        if(length > 0){
            return response;
        }
    }
    Response response{false, 0};
    return response;
}

extern "C"
JNIEXPORT void JNICALL
Java_mobisocial_arcade_ESPView_DrawOn(JNIEnv *env, jclass clazz, jobject esp_view, jobject canvas) {
    espOverlay = ESP(env, esp_view, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}
extern "C"
JNIEXPORT jint JNICALL
Java_mobisocial_arcade_lite_LiteOverlay_LiteInit(JNIEnv *env, jclass clazz) {
    return startClient();
}extern "C"
JNIEXPORT void JNICALL
Java_mobisocial_arcade_lite_LiteOverlay_LiteSize(JNIEnv *env, jclass clazz, jint num, jfloat size) {
    switch (num){
        case 999:
            playerTextSize = size;
            break;
        case 1000:
            itemTextSize = size;
            break;
        default:
            break;
    }
}extern "C"
JNIEXPORT void JNICALL
Java_mobisocial_arcade_lite_LiteOverlay_LiteStop(JNIEnv *env, jclass clazz) {
    stopClient();
}
extern "C"
JNIEXPORT void JNICALL
Java_mobisocial_arcade_lite_LiteFloatLogo_LitePremiumValue(JNIEnv *env, jclass clazz, jint setting_code,
                                                         jboolean flag) {
    switch (setting_code){
        case 600:
            isESP = flag;
            break;
        case 601:
            isPlayerName = flag;
            break;
        case 602:
            isPlayerHealth = flag;
            break;
        case 603:
            isPlayerDist = flag;
            break;
        case 604:
            isTeamMateShow = flag;
            break;
        case 605:
            isPlayerLine = flag;
            break;
        case 606:
            isPlayerBox = flag;
            break;
        case 607:
            isPlayer360 = flag;
            break;
        case 608:
            isNearEnemy = flag;
            break;
        case 609:
            isItemName = flag;
            break;
        case 610:
            isItemDist = flag;
            break;
        case 611:
            isVehicle = flag;
            break;
        case 612:
            isLootBox = flag;
            break;
        case 613:
            isLootItems = flag;
            break;
        case 614:
            isPlayerSkel = flag;
            break;
        case 615:
            isAirDrop = flag;
            break;
        case 616:
            isteamid = flag;
        default:
            break;
    }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {}