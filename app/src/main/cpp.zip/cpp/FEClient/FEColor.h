#ifndef FECOLOR_H
#define FECOLOR_H

class FEColor {
public:
    float r;
    float g;
    float b;
    float a;

    FEColor() {
        this->r = 0;
        this->g = 0;
        this->b = 0;
        this->a = 0;
    }

    FEColor(float r, float g, float b, float a) {
        this->r = r;
        this->g = g;
        this->b = b;
        this->a = a;
    }

    FEColor(float r, float g, float b) {
        this->r = r;
        this->g = g;
        this->b = b;
        this->a = 225;
    }

    static FEColor Clear() {
        return FEColor(0, 0, 0, 0);
    }

    static FEColor Black() {
        return FEColor(0, 0, 0);
    }

    static FEColor BlackT() {
        return FEColor(0, 0, 0, 135);
    }


    static FEColor White() {
        return FEColor(255, 255, 255);
    }

    static FEColor Red() {
        return FEColor(255, 0, 0);
    }

    static FEColor RedTT() {
        return FEColor(255, 0, 0, 200);
    }


    static FEColor RedT() {
        return FEColor(255, 0, 0, 60);
    }


    static FEColor Yellow() {
        return FEColor(255, 255, 0, 250);
    }

    static FEColor Green() {
        return FEColor(0, 255, 0, 200);
    }

    static FEColor Yellow4() {
        return FEColor(255, 145, 0, 125);
    }

    static FEColor Green4() {
        return FEColor(0, 210, 0, 125);
    }

    static FEColor Orange1() {
        return FEColor(255, 155, 50, 100);
    }

    static FEColor OrangeTT() {
        return FEColor(255, 155, 50, 200);
    }

    static FEColor Green1() {
        return FEColor(0, 220, 0, 100);
    }

    static FEColor Orange2() {
        return FEColor(255, 155, 60, 75);
    }

    static FEColor Green2() {
        return FEColor(0, 255, 0, 75);
    }

    static FEColor GreenTT() {
        return FEColor(0, 255, 0, 200);
    }

    static FEColor Orange3() {
        return FEColor(255, 255, 0, 50);
    }

    static FEColor Orange() {
        return FEColor(255, 155, 0, 255);
    }

    static FEColor OrangeD() {
        return FEColor(255, 65, 0, 255);
    }

    static FEColor Green3() {
        return FEColor(0, 255, 0, 50);
    }

    static FEColor Coral() {
    return FEColor(240,128,128);
}

    static FEColor Cyan(){
        return FEColor(0, 255, 255);
    }

    static FEColor CyanT(){
        return FEColor(0, 255, 255,60);
    }

    static FEColor Blue(){
        return FEColor(0, 0, 255);
    }

    static FEColor Purple(){
        return FEColor(128, 0, 128);
    }

    static FEColor Maroon(){
        return FEColor(128, 0, 0);
    }

    static FEColor Grey(){
        return FEColor(195,190,190);
    }

    static FEColor Gold(){
        return FEColor(255,190,0);
    }

    static FEColor SmokeyBlack(){
        return FEColor(25,0,15);
    }

    static FEColor Crimson(){
        return FEColor(225,35,55);
    }

    static FEColor Magenta() {
        return FEColor(255,20,147);
    }

    static FEColor MagentaD() {
        return FEColor(255,192,203);
    }

    static FEColor Aero(){
        return FEColor(189,59,12);
    }

    static FEColor Almond(){
        return FEColor(235,220,205);
    }

    static FEColor Ice(){
        return FEColor(240,250,255);
    }

    static FEColor Alien(){
        return FEColor(130,220,5);
    }

    static FEColor AlienT(){
        return FEColor(130,220,5, 60);
    }

    static FEColor RedLight(){
        return FEColor(255, 0, 0,100);
    }

    static FEColor YellowLight(){
        return FEColor(255, 255, 0,100);
    }

};

#endif
