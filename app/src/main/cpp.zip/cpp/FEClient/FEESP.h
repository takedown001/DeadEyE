#ifndef ESP_H
#define ESP_H

#include <jni.h>
#include "FEColor.h"
#include "FERect.h"
#include "FEVector2.h"
#include "FEVector3.h"

class FEESP {
private:
    JNIEnv *_env;
    jobject _cvsView;
    jobject _cvs;
public:
    FEESP() {
        _env = nullptr;
        _cvsView = nullptr;
        _cvs = nullptr;
    }

    FEESP(JNIEnv *env, jobject cvsView, jobject cvs) {
        this->_env = env;
        this->_cvsView = cvsView;
        this->_cvs = cvs;
    }

    JNIEnv *getEnviroument() const {
        return _env;
    }

    jobject getEspView() const {
        return _cvsView;
    }

    jobject getCanavas() const {
        return _cvs;
    }

    bool isValid() const {
        return (_env != nullptr && _cvsView != nullptr && _cvs != nullptr);
    }

    int getWidth() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, "getWidth", "()I");
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    int getHeight() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, "getHeight", "()I");
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    void invalidate() {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID inavlidate = _env->GetMethodID(canvasView, "invalidate", "()V");
            _env->CallVoidMethod(_cvsView, inavlidate);
        }
    }

    void postInvalidate() {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID inavlidate = _env->GetMethodID(canvasView, "postInvalidate", "()V");
            _env->CallVoidMethod(_cvsView, inavlidate);
        }
    }

    void ClearCanvas() {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID clearCanvas = _env->GetMethodID(canvasView, "ClearCanvas",
                                                      "(Landroid/graphics/Canvas;)V");
            _env->CallVoidMethod(_cvsView, clearCanvas, _cvs);
        }
    }

    void DrawLine(FEColor color, float thickness, FEVector2 start, FEVector2 end) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawline = _env->GetMethodID(canvasView, "DrawLine",
                                                   "(Landroid/graphics/Canvas;IIIIFFFFF)V");
            _env->CallVoidMethod(_cvsView, drawline, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 thickness,
                                 start.x, start.y, end.x, end.y);
        }
    }

    void DrawText(FEColor color, const char *txt, FEVector2 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, "DrawText",
                                                   "(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V");
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 _env->NewStringUTF(txt), pos.x, pos.y, size);
        }
    }

    void DrawPlayerText(FEColor color, const wchar_t *txt, FEVector2 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, "DrawText",
                                                   "(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V");
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 wcstojstr(_env, txt), pos.x, pos.y, size);
        }
    }

    static jstring wcstojstr(JNIEnv *env, const wchar_t *input) {
        jobject bb = env->NewDirectByteBuffer((void *)input, wcslen(input) * sizeof(wchar_t));
        jstring UTF32LE = env->NewStringUTF("UTF-32LE");

        jclass charsetClass = env->FindClass("java/nio/charset/Charset");
        jmethodID forNameMethod = env->GetStaticMethodID(charsetClass, "forName", "(Ljava/lang/String;)Ljava/nio/charset/Charset;");
        jobject charset = env->CallStaticObjectMethod(charsetClass, forNameMethod, UTF32LE);

        jmethodID decodeMethod = env->GetMethodID(charsetClass, "decode", "(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;");
        jobject cb = env->CallObjectMethod(charset, decodeMethod, bb);

        jclass charBufferClass = env->FindClass("java/nio/CharBuffer");
        jmethodID toStringMethod = env->GetMethodID(charBufferClass, "toString", "()Ljava/lang/String;");
        jstring ret = (jstring)env->CallObjectMethod(cb, toStringMethod);

        env->DeleteLocalRef(bb);
        env->DeleteLocalRef(UTF32LE);
        env->DeleteLocalRef(charsetClass);
        env->DeleteLocalRef(charset);
        env->DeleteLocalRef(cb);
        env->DeleteLocalRef(charBufferClass);

        return ret;
    }

    void DrawCircle(FEColor color, float thickness, FEVector2 pos, float radius) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawcircle = _env->GetMethodID(canvasView, "DrawCircle",
                                                     "(Landroid/graphics/Canvas;IIIIFFFF)V");
            _env->CallVoidMethod(_cvsView, drawcircle, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 thickness,
                                 pos.x, pos.y, radius);
        }
    }

    void DrawFilledCircle(FEColor color, FEVector2 pos, float radius) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawfilledcircle = _env->GetMethodID(canvasView, "DrawFilledCircle",
                                                           "(Landroid/graphics/Canvas;IIIIFFF)V");
            _env->CallVoidMethod(_cvsView, drawfilledcircle, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b, pos.x, pos.y, radius);
        }
    }

    void DrawRect(FEColor color, int thickness, FERect rect) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawrect = _env->GetMethodID(canvasView, "DrawRect",
                                                   "(Landroid/graphics/Canvas;IIIIIFFFF)V");
            _env->CallVoidMethod(_cvsView, drawrect, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b, thickness,
                                 rect.x, rect.y, rect.width, rect.height);
        }
    }

    void DrawFilledRect(FEColor color, FERect rect) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawfilledrect = _env->GetMethodID(canvasView, "DrawFilledRect",
                                                         "(Landroid/graphics/Canvas;IIIIFFFF)V");
            _env->CallVoidMethod(_cvsView, drawfilledrect, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 rect.x, rect.y, rect.width, rect.height);
        }
    }

    void DrawLineBorder(FEColor color, float stroke, FERect rect) {
        // top left
        FEVector2 v1 = FEVector2(rect.x, rect.y);
        // top right
        FEVector2 v2 = FEVector2(rect.x + rect.width, rect.y);
        // bottom right
        FEVector2 v3 = FEVector2(rect.x + rect.width, rect.y + rect.height);
        // bottom left
        FEVector2 v4 = FEVector2(rect.x, rect.y + rect.height);

        // top left to top right
        DrawLine(color, stroke, v1, v2);
        // top right to bottom right
        DrawLine(color, stroke, v2, v3);
        // bottom right to bottom left
        DrawLine(color, stroke, v3, v4);
        // bottom left to top left
        DrawLine(color, stroke, v4, v1);
    }

    void DrawHorizontalHealthBar(FEVector2 screenPos, float width, float maxHealth, float currentHealth) {
        screenPos -= FEVector2(0.0f, 8.0f);
        float hpWidth = (currentHealth * width) / maxHealth;
        //      DrawLineBorder(FEColor(0, 0, 0, 255), 3, FERect(screenPos.x, screenPos.y,  ((width) + 20), 5.0f));
        DrawRect(FEColor::Black(),1,FERect(screenPos.x-16, screenPos.y-17, hpWidth+36 , 40));
        screenPos += FEVector2(1.0f, 1.0f);
        FEColor clr = FEColor(0, 200, 0, 100);

        if (currentHealth <= (maxHealth * 0.6)) {
            clr = FEColor(200, 200, 0, 100);
        }
        if (currentHealth < (maxHealth * 0.3)) {
            clr = FEColor(200, 0, 0, 100);
        }
        DrawRect(clr, 33, FERect(screenPos.x, screenPos.y, hpWidth, 4.0f));
    }

    void DrawHealthBar(FEVector2 screenPos, float width, float maxHealth, float currentHealth){
        screenPos -= FEVector2(0.0f, 8.0f);
        DrawLineBorder(FEColor::BlackT(), 1.5, FERect(screenPos.x, screenPos.y, width+26, 31.00f));
        screenPos += FEVector2(1.0f, 1.0f);
        FEColor clr = FEColor(0, 200, 0, 135);
        float hpWidth = (currentHealth * width) / maxHealth;
        if (currentHealth <= (maxHealth * 0.6)) {
            clr = FEColor(200, 200, 0, 135);
        }
        if (currentHealth < (maxHealth * 0.3)) {
            clr = FEColor(200, 0, 0, 135);
        }
        DrawFilledRect(clr, FERect(screenPos.x, screenPos.y, hpWidth+24, 29.00f));
        DrawLineBorder(clr, 4, FERect(screenPos.x, screenPos.y, hpWidth+26, 31.00));
        DrawLineBorder(FEColor::BlackT(), 1.5, FERect(screenPos.x, screenPos.y, width+26, 31.00f));
    }

    void DrawHorizontalHealthBarFree(FEVector2 screenPos, float width, float maxHealth, float currentHealth) {
        screenPos -= FEVector2(0.0f, 8.0f);
        DrawLineBorder(FEColor(0, 0, 0, 255), 3, FERect(screenPos.x, screenPos.y, width + 2, 5.0f));
        screenPos += FEVector2(1.0f, 1.0f);
        FEColor clr = FEColor(0, 255, 0, 255);
        float hpWidth = (currentHealth * width) / maxHealth;
        if (currentHealth <= (maxHealth * 0.6)) {
            clr = FEColor(255, 255, 0, 255);
        }
        if (currentHealth < (maxHealth * 0.3)) {
            clr = FEColor(255, 0, 0, 255);
        }
        DrawLineBorder(clr, 3, FERect(screenPos.x, screenPos.y, hpWidth, 4.0f));
    }
    void DrawVerticalHealthBar(FEVector2 screenPos, float height, float maxHealth, float currentHealth) {
        screenPos += FEVector2(8.0f, 0.0f);
        DrawLineBorder(FEColor(0, 0, 0, 255), 3, FERect(screenPos.x, screenPos.y, 5.0f, height + 10));
        screenPos += FEVector2(1.0f, 1.0f);
        FEColor clr = FEColor(0, 255, 0, 255);
        float barHeight = (currentHealth * height) / maxHealth;
        if (currentHealth <= (maxHealth * 0.6)) {
            clr = FEColor(255, 255, 0, 255);
        }
        if (currentHealth < (maxHealth * 0.3)) {
            clr = FEColor(255, 0, 0, 255);
        }
        DrawLineBorder(clr, 3, FERect(screenPos.x, screenPos.y, 3.0f, barHeight));
    }

    void DrawCrosshair(FEColor clr, FEVector2 center, float size = 20) {
        float x = center.x - (size / 2.0f);
        float y = center.y - (size / 2.0f);
        DrawLine(clr, 3, FEVector2(x, center.y), FEVector2(x + size, center.y));
        DrawLine(clr, 3, FEVector2(center.x, y), FEVector2(center.x, y + size));
    }
};

#endif
