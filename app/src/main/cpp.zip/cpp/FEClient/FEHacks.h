#ifndef HACKS_H
#define HACKS_H

#include "FEDeadeye.h"

bool isValidPlayer(PlayerData data){
    return (data.Body != FEVector2::Zero() && data.Head != FEVector2::Zero());
}

bool isValidItem(ItemData data){
    return (data.Location != FEVector2::Zero());
}
bool isValidVehical(VehicalData data){
    return (data.Location != FEVector2::Zero());
}
/*int isOutsideSafezone(Vector2 pos, Vector2 screen) {
    Vector2 mSafezoneTopLeft(screen.x * 0.04f, screen.y * 0.04f);
    Vector2 mSafezoneBottomRight(screen.x * 0.96f, screen.y * 0.96f);

    int result = 0;
    if (pos.y < mSafezoneTopLeft.y) {
        // top
        result |= 1;
    }
    if (pos.x > mSafezoneBottomRight.x) {
        // right
        result |= 2;
    }
    if (pos.y > mSafezoneBottomRight.y) {
        // bottom
        result |= 4;
    }
    if (pos.x < mSafezoneTopLeft.x) {
        // left
        result |= 8;
    }
    return result;
}*/

FEVector2 pushToScreenBorder(FEVector2 Pos, FEVector2 screen, int offset) {
    int x = (int)Pos.x;
    int y = (int)Pos.y;
    if (Pos.y < 0) {
        // top
        y = -offset;
    }
    if (Pos.x > screen.x) {
        // right
        x = (int)screen.x + offset;
    }
    if (Pos.y > screen.y) {
        // bottom
        y = (int)screen.y + offset;
    }
    if (Pos.x < 0) {
        // left
        x = -offset;
    }
    return FEVector2(x, y);
}

bool isInCenter(FERect box,int screenWidth, int screenHeight){
    FEVector2 centerPos = FEVector2(screenWidth / 2, screenHeight / 2);
    bool  w = false;
    if(box.x < centerPos.x  && box.y < centerPos.y){
        w = true;
    }
    return w;
}

bool isOutsideSafeZone(FEVector2 pos, FEVector2 screen) {
    if (pos.y < 0) {
        return true;
    }
    if (pos.x > screen.x) {
        return true;
    }
    if (pos.y > screen.y) {
        return true;
    }
    return pos.x < 0;
}

void DrawESP(FEESP esp, int screenWidth, int screenHeight) {
    if (isfov) {
        esp.DrawCircle(FEColor(255, 0, 0, 200), 2,
                       FEVector2(screenWidth / 2, screenHeight / 2), 130);
    }
    if(iscrosshair){
        esp.DrawCrosshair(FEColor(0, 0, 0, 255), FEVector2(screenWidth / 2, screenHeight / 2), 42);
    }
        if (isdaemon) {
            esp.DrawText(FEColor(255,69,0), "Daemon Status :", FEVector2(500, 55), 20);
            esp.DrawText(FEColor::Green(), "Success", FEVector2(650, 55), 20);

        } else {
            esp.DrawText(FEColor(255,69,0), "Daemon Status :", FEVector2(500, 55), 20);
            esp.DrawText(FEColor::Orange(), "Failed", FEVector2(650, 55), 20);
        }
    FEVector2 screen(screenWidth, screenHeight);
    float mScale = screenHeight / (float) 1080;
    esp.DrawText(FEColor::Red(), "@DeadEye_TG", FEVector2(
            (screenWidth) - 130, (screenHeight) - 60), 20);

    Response response = getData(screenWidth, screenHeight);
    if (response.Success) {
        if(isNearEnemy) {
            FEColor color = FEColor(75,175,80,110);
            FEColor coloor = FEColor(255,65,0,110);
            FEColor colooor = FEColor(255,0,0,110);
            if (response.NearEnemy == 0) {
                string enemyData = " CLEAR ";
                int boxWidth = 180;
                int boxHeight = 60;
                esp.DrawFilledRect(color, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawRect(FEColor(0,200,0), 5, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawText(FEColor::White(), enemyData.c_str(), FEVector2((screenWidth / 2), 117), 30);
            } else if (response.NearEnemy > 0 && response.NearEnemy < 8) {
                string enemyData = to_string(response.NearEnemy);
                int boxWidth = 180;
                int boxHeight = 60;
                esp.DrawFilledRect(coloor, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawRect(FEColor::OrangeD(), 5, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawText(FEColor::White(), enemyData.c_str(), FEVector2((screenWidth / 2), 117), 30);
            } else {
                string enemyData = to_string(response.NearEnemy);
                int boxWidth = 180;
                int boxHeight = 60;
                esp.DrawFilledRect(colooor, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawRect(FEColor::Red(), 5, FERect((screenWidth / 2) - (boxWidth / 2), 77, boxWidth, boxHeight));
                esp.DrawText(FEColor::White(), enemyData.c_str(), FEVector2((screenWidth / 2), 117), 30);
            }
        }
        int count = response.PlayerCount;
        if (count > 0) {
            for (int i = 0; i < count; i++) {
                 PlayerData player = response.Players[i];
                if (!isValidPlayer(player)) { continue; }

                bool isTeamMate = player.TeamID == response.MyTeamID;
                if (isTeamMate && !isTeamMateShow) { continue; }

                FEVector2 location = player.Body;
                if (isPlayer360 && isOutsideSafeZone(location, screen)) {
                    string dist;
                    dist += to_string((int) player.Distance);
                    dist += "m";

                    FEVector2 hintDotRenderPos = pushToScreenBorder(location, screen,
                                                                    (int) ((mScale * 100) /
                                                                           3));
                    FEVector2 hintTextRenderPos = pushToScreenBorder(location, screen,
                                                                     -(int) ((mScale *
                                                                              36)));
                    if(player.Distance < 70) {
                        esp.DrawFilledCircle(
                                FEColor::RedTT(),
                                hintDotRenderPos, (mScale * 100));
                        esp.DrawText(FEColor::White(), dist.c_str(), hintTextRenderPos,
                                     playerTextSize);
                    } else if(player.Distance < 140 && player.Distance > 70) {
                        esp.DrawFilledCircle(
                                FEColor::OrangeTT(),
                                hintDotRenderPos, (mScale * 100));
                        esp.DrawText(FEColor::White(), dist.c_str(), hintTextRenderPos,
                                     playerTextSize);
                    } else {
                        esp.DrawFilledCircle(
                                FEColor::GreenTT(),
                                hintDotRenderPos, (mScale * 100));
                        esp.DrawText(FEColor::White(), dist.c_str(), hintTextRenderPos,
                                     playerTextSize);
                    }
                    continue;
                }

                float boxHeight = fabsf(player.Root.y - player.Head.y);
                float boxWidth = boxHeight * 0.56;
                FERect Box(player.Head.x - (boxWidth / 2), player.Head.y, boxWidth,
                           boxHeight);
                bool playerInCenter = isInCenter(Box,screenWidth,screenHeight);

                if (isPlayerSkel) {

                    if (!player.isBot) {
                        FEColor skclr = playerInCenter ? FEColor::Alien() : FEColor(255,10,0);
                        esp.DrawCircle(skclr, 3, player.Neck, boxWidth / 6);
                        esp.DrawLine(skclr, 3, player.Neck, player.Chest);
                        esp.DrawLine(skclr, 3, player.Chest, player.Pelvis);
                        esp.DrawLine(skclr, 3, player.Chest, player.LShoulder);
                        esp.DrawLine(skclr, 3, player.Chest, player.RShoulder);
                        esp.DrawLine(skclr, 3, player.LShoulder, player.LElbow);
                        esp.DrawLine(skclr, 3, player.RShoulder, player.RElbow);
                        esp.DrawLine(skclr, 3, player.LElbow, player.LWrist);
                        esp.DrawLine(skclr, 3, player.RElbow, player.RWrist);
                        esp.DrawLine(skclr, 3, player.Pelvis, player.LThigh);
                        esp.DrawLine(skclr, 3, player.Pelvis, player.RThigh);
                        esp.DrawLine(skclr, 3, player.LThigh, player.LKnee);
                        esp.DrawLine(skclr, 3, player.RThigh, player.RKnee);
                        esp.DrawLine(skclr, 3, player.LKnee, player.LAnkle);
                        esp.DrawLine(skclr, 3, player.RKnee, player.RAnkle);
                    } else {
                        FEColor skoclr = playerInCenter ? FEColor::Alien() : FEColor::Cyan();
                        esp.DrawCircle(skoclr, 3, player.Neck, boxWidth / 6);
                        esp.DrawLine(skoclr, 3, player.Neck, player.Chest);
                        esp.DrawLine(skoclr, 3, player.Chest, player.Pelvis);
                        esp.DrawLine(skoclr, 3, player.Chest, player.LShoulder);
                        esp.DrawLine(skoclr, 3, player.Chest, player.RShoulder);
                        esp.DrawLine(skoclr, 3, player.LShoulder, player.LElbow);
                        esp.DrawLine(skoclr, 3, player.RShoulder, player.RElbow);
                        esp.DrawLine(skoclr, 3, player.LElbow, player.LWrist);
                        esp.DrawLine(skoclr, 3, player.RElbow, player.RWrist);
                        esp.DrawLine(skoclr, 3, player.Pelvis, player.LThigh);
                        esp.DrawLine(skoclr, 3, player.Pelvis, player.RThigh);
                        esp.DrawLine(skoclr, 3, player.LThigh, player.LKnee);
                        esp.DrawLine(skoclr, 3, player.RThigh, player.RKnee);
                        esp.DrawLine(skoclr, 3, player.LKnee, player.LAnkle);
                        esp.DrawLine(skoclr, 3, player.RKnee, player.RAnkle);
                    }
                }
                if (isPlayerLine) {
                    if (player.isBot) {

                        FEColor lcolor = playerInCenter ? FEColor::Alien() : FEColor::Cyan();
                        if(islinecenter){
                            esp.DrawLine(lcolor, 2, FEVector2((screenWidth / 2), (screenHeight / 2)), player.Neck);
                        }else if (islinedown){
                            esp.DrawLine(lcolor, 2,
                                         FEVector2((screenWidth / 2), screenHeight), (player.Root));
                        }else{
                            esp.DrawLine(lcolor, 2, FEVector2((screenWidth / 2), 0), player.Neck);
                        }
                    } else {
                        FEColor lcolor = playerInCenter ? FEColor::Alien() : FEColor::Red();
                        if(islinecenter){
                            esp.DrawLine(lcolor, 2, FEVector2((screenWidth / 2), (screenHeight / 2)), player.Neck);
                        }else if (islinedown){
                            esp.DrawLine(lcolor, 2,
                                         FEVector2((screenWidth / 2), screenHeight), (player.Root));
                        }else{
                            esp.DrawLine(lcolor, 2, FEVector2((screenWidth / 2), 0), player.Neck);
                        }

                    }
                }

                if (isPlayerBox) {
                    if (player.isBot) {
                        FEColor bxclr = playerInCenter ? FEColor::Alien() : FEColor::Cyan();
                        FEColor bxxclr = playerInCenter ? FEColor::AlienT() : FEColor::CyanT();
                        esp.DrawFilledRect(bxxclr, Box);
                        esp.DrawRect(bxclr, 2, Box);
                    } else {
                        FEColor bxclr = playerInCenter ? FEColor::Alien() : FEColor::Red();
                        FEColor bxxclr = playerInCenter ? FEColor::AlienT() : FEColor::RedT();
                        esp.DrawFilledRect(bxxclr, Box);
                        esp.DrawRect(bxclr, 2, Box);


                    }

                }

                FERect Boxxx((player.Head.x - (boxWidth / 2)) + 10, (player.Head.y - 10), boxWidth, boxHeight);
                FERect Boxx((player.Head.x - (boxWidth / 2)) - 10, player.Head.y, boxWidth, boxHeight);
                if(is3DPlayerBox){
                    if (player.isBot) {
                       FEColor bxclr = playerInCenter ? FEColor::Alien() : FEColor::Cyan();
                         FEColor bxxclr = playerInCenter ? FEColor::AlienT() : FEColor::CyanT();
                        esp.DrawFilledRect(bxxclr, Boxxx);
                        esp.DrawFilledRect(bxxclr, Boxx);
                        esp.DrawRect(bxclr, 3, Boxxx);
                        esp.DrawRect(bxclr, 3, Boxx);
                    } else {
                        FEColor bxclr = playerInCenter ? FEColor::Alien() : FEColor::Red();
                        FEColor bxxclr = playerInCenter ? FEColor::AlienT() : FEColor::RedT();
                        esp.DrawFilledRect(bxxclr, Boxxx);
                        esp.DrawFilledRect(bxxclr, Boxx);
                        esp.DrawRect(bxclr, 3, Boxxx);
                        esp.DrawRect(bxclr, 3, Boxx);
                    }
                }

                if (isPlayerHealth) {
                    esp.DrawHealthBar(
                            FEVector2(Box.x + (Box.width / 2) - 65, Box.y - 30),
                            (115 * mScale),
                            100, player.Health);
                }
                if(isverticlhealth){
                    esp.DrawVerticalHealthBar(
                            FEVector2(Box.x + Box.width, Box.y),
                            boxHeight,
                            100, player.Health);
                }
                if(isPlayerName) {
                    wstring pname = player.PlayerName;
                    wstring bname = L" AI ";


                    if(player.isBot) {
                        esp.DrawPlayerText(FEColor::White(), bname.c_str(),
                                           FEVector2(Box.x + (Box.width / 2), Box.y -18),
                                           ((30 * mScale)) / 2);
                    } else {
                        esp.DrawPlayerText(FEColor::White(), pname.c_str(),
                                           FEVector2(Box.x + (Box.width / 2) , Box.y -18),
                                           ((30 * mScale)) / 2);

                    }
                }
                if (isteamid) {
                    wstring teamid = L" " + to_wstring(player.TeamID) ;
                    esp.DrawPlayerText(FEColor::Orange(), teamid.c_str(),
                                       FEVector2((Box.x + (Box.width / 2)) - 75,
                                                 Box.y - 30),
                                       ((35 * mScale)) / 2);
                }


//                if (isplayeruid) {
//                   wstring playerid = L" " + to_wstring(player.PlayerID);
//                    esp.DrawPlayerText(FEColor::White(), playerid.c_str(),
//                                       FEVector2(Box.x + (Box.width / 2) - 70,
//                                                 Box.y + 22),
//                                       ((32 * mScale)) / 2);
    //            }

                if (isPlayerDist) {
                    string dist;
                    dist += to_string((int) player.Distance);
                    dist += "m";

                    esp.DrawText(FEColor::Orange(), dist.c_str(),
                                 FEVector2(Box.x + (Box.width / 2),
                                           Box.y + Box.height + 25),
                                 playerTextSize);
                }


            }
        }

        count = response.ItemsCount;
        if(count > 0) {
            for (int i = 0; i < count; i++) {
                ItemData item = response.Items[i];
                if (!isValidItem(item)) { continue; }

                FEVector2 location = item.Location;

                string dist;
                dist += to_string((int) item.Distance);
                dist += "m";

                if ((strstr(item.Name, "MedKit") && isMedKit) ||
                    (strstr(item.Name, "FirstAid") && isFirstAid) ||
                    (strstr(item.Name, "Injection") && isInjection) ||
                    (strstr(item.Name, "Painkiller") && isPainkiller) ||
                    (strstr(item.Name, "Drink") && isDrink) ||
                    (strstr(item.Name, "Bandage") && isBandage)) {
                    esp.DrawText(FEColor::Alien(), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
                if ((strstr(item.Name, "Armor L3") && armor3) ||
                    (strstr(item.Name, "Helmet L3") && helmet3) ||
                    (strstr(item.Name, "Bag L3") && bagl3) ||
                    (strstr(item.Name, "Armor L2") && armor2) ||
                    (strstr(item.Name, "Helmet L2") && helmet2) ||
                    (strstr(item.Name, "Bag L2") && bagl2) || (strstr(item.Name, "Bag L1") && bagl1) || (strstr(item.Name, "Armor L1") && armor1) || (strstr(item.Name, "Helmet L1") && helmet1)) {
                    esp.DrawText(FEColor::SmokeyBlack(), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
                if ((strstr(item.Name, "7.62mm") && isssm) ||
                    (strstr(item.Name, "5.56mm") && isffm) ||
                    (strstr(item.Name, "45ACP") && isACP) ||
                    (strstr(item.Name, "9mm") && is9mm) ||
                    (strstr(item.Name, "300Magnum") && is300magneum) ||
                    (strstr(item.Name, "arrow") && isarrow) || (strstr(item.Name, "12 Guage") && is12guage)) {
                    esp.DrawText(FEColor::Gold(), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
                if ((strstr(item.Name, "HoloSignt") && hollow) ||
                    (strstr(item.Name, "Canted Sight") && Caneted) ||
                    (strstr(item.Name, "RedDot") && Reddot) ||
                    (strstr(item.Name, "8x") && is8x) ||
                    (strstr(item.Name, "4x") && is4x) ||
                    (strstr(item.Name, "2x") && is2x) || (strstr(item.Name, "3x") && is3x) || (strstr(item.Name, "6x") && is6x)) {
                    esp.DrawText(FEColor(179,61,81), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
                if ((strstr(item.Name, "FlareGun") && isflare) ||
                    (strstr(item.Name, "Ghillie") && Gilli) ||
                    (strstr(item.Name, "AirDrop") && Airdrop) ||
                    (strstr(item.Name, "Plane") && DropPlane) ||
                    (strstr(item.Name, "Crate") && Crate)) {
                    esp.DrawText(FEColor::Crimson(), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
                if ((strstr(item.Name, "AKM") && isakm) ||
                    (strstr(item.Name, "M416") && ism416) ||
                    (strstr(item.Name, "QBZ") && isQBZ) ||
                    (strstr(item.Name, "M24") && ism24) ||
                    (strstr(item.Name, "SCAR L") && isscarl) ||
                    (strstr(item.Name, "M762") && ism762)||
                    (strstr(item.Name, "M16A4") && ism416a4)||
                    (strstr(item.Name, "Mk47 Mutant") && ismk47)||
                    (strstr(item.Name, "G36C") && isG36C)||
                    (strstr(item.Name, "Groza") && isGroza)||
                    (strstr(item.Name, "AUG A3") && isAug)||
                    (strstr(item.Name, "QBU") && isQBU)||
                    (strstr(item.Name, "SLR") && isSLR)||
                    (strstr(item.Name, "SKS") && issks)||
                    (strstr(item.Name, "Kar98k") && iskar98 ) ||
                    (strstr(item.Name, "VSS") && isvss  ) ||
                    (strstr(item.Name, "Win94") && iswin94 ) ||
                    (strstr(item.Name, "PP19Bizon") && isBizon ) ||
                    (strstr(item.Name, "Uzi") && isuzi )||
                    (strstr(item.Name, "MK14") && ismk14 )||
                    (strstr(item.Name, "M249") && ism249 ) ||
                    (strstr(item.Name, "Vector") && isvector ) ||
                    (strstr(item.Name, "DP28") && isdp28 ) ||
                    (strstr(item.Name, "AWM") && isAWM ) ||
                    (strstr(item.Name, "Mini14") && isMini14 ) ||
                    (strstr(item.Name, "UMP9") && isUmp ) ||
                    (strstr(item.Name, "MP5K") && ismp5k ) ||
                    (strstr(item.Name, "Tommy Gun") && istommy ) ||
                    (strstr(item.Name, "Mosin Nagant") && isMosin ) ||
                    (strstr(item.Name, "FAMAS")  )
                        ){
                    esp.DrawText(FEColor(108,31,146), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }

                if (strstr(item.Name, "Grenadew") && iswarning) {
                    if (item.Distance < 15) {
                        esp.DrawText(FEColor::Red(),
                                     "Warning : There is Grenade near You",
                                     FEVector2(screenWidth / 2, (screenHeight / 8) + 9),
                                     30);
                    }
                    if (!(i % 2 == 0)) {
                        esp.DrawCircle(FEColor::Yellow(), 3, FEVector2(
                                location.x, location.y + (21 * mScale)), 15);
                        esp.DrawFilledCircle(FEColor::YellowLight(), FEVector2(
                                location.x, location.y + (20 * mScale)), 15);
                    } else {
                        esp.DrawCircle(FEColor::Red(), 3, FEVector2(
                                location.x, location.y + (21 * mScale)), 15);
                        esp.DrawFilledCircle(FEColor::RedLight(), FEVector2(
                                location.x, location.y + (20 * mScale)), 15);
                    }

                    esp.DrawText(FEColor::Red(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);
                }
                if(strstr(item.Name, "Molotovw") && iswarning){
                    if(item.Distance < 15) {
                        esp.DrawText(FEColor::Red(), "Warning : There is Mototov near You",
                                     FEVector2(screenWidth / 2, (screenHeight /8 ) + 9),
                                     30);
                    }    esp.DrawText(FEColor::Red(),"Molotov", FEVector2(
                            location.x, location.y + (20 * mScale)),
                                      itemTextSize);
                    esp.DrawText(FEColor::Red(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);

                }
                if(strstr(item.Name, "Sticky BombW") && iswarning){
                    if(item.Distance < 15) {
                        esp.DrawText(FEColor::Red(), "Warning : There is Sticky Bomb near You",
                                     FEVector2(screenWidth / 2, (screenHeight /8 ) + 9),
                                     30);
                    }    esp.DrawText(FEColor::Red(),"Sticky Bomb", FEVector2(
                            location.x, location.y + (20 * mScale)),
                                      itemTextSize);
                    esp.DrawText(FEColor::Red(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);

                }
                if(strstr(item.Name, "Spike TrapW") && iswarning){
                    if(item.Distance < 15) {
                        esp.DrawText(FEColor::Red(), "Warning : There is Spike Trap near You",
                                     FEVector2(screenWidth / 2, (screenHeight /8 ) + 9),
                                     30);
                    }    esp.DrawText(FEColor::Red(),"Spike Trap", FEVector2(
                            location.x, location.y + (20 * mScale)),
                                      itemTextSize);
                    esp.DrawText(FEColor::Red(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);

                }
                if ((strstr(item.Name, "Grenade") && isgranade) || (strstr(item.Name, "Molotov") && ismolo) || (strstr(item.Name, "Smoke") && issmoke) || (strstr(item.Name, "Sticky Bomb") && isstickeybomb) || (strstr(item.Name, "Spike Trap") && isspiketrap) ){

                    esp.DrawText(FEColor::Almond(),item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)),
                                 itemTextSize);
                    esp.DrawText(FEColor::White(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);
                }

                if (isItemName) {
                    esp.DrawText(FEColor::MagentaD(), item.Name, FEVector2(
                            location.x, location.y + (20 * mScale)),
                                 itemTextSize);

                }

                if (isItemDist) {
                    esp.DrawText(FEColor::Coral(), dist.c_str(),
                                 FEVector2(
                                         location.x,
                                         location.y + (40 * mScale)),
                                 itemTextSize);
                }
            }
        }
        count = response.VehicalCount;
        if(count>0) {
            for (int i = 0; i < count; i++) {

                VehicalData vehical = response.Vehical[i];
                if (!isValidVehical(vehical)) { continue; }

                FEVector2 location = vehical.Location;
                string dist;
                dist += to_string((int) vehical.Distance);
                dist += "m";

                if ((strstr(vehical.Name, "Buggy") && isbuggy) ||
                    (strstr(vehical.Name, "UAZ") && isUAZ) ||
                    (strstr(vehical.Name, "Dacia") && isDacia) ||
                    (strstr(vehical.Name, "Rony") && isRony) ||
                    (strstr(vehical.Name, "Mirado") && isMirado) ||
                    (strstr(vehical.Name, "Scooter") && isscooter) ||
                    (strstr(vehical.Name, "LadaNiva") && isLadaNiva) ||
                    (strstr(vehical.Name, "Pickup") && istruck)) {
                    esp.DrawText(FEColor::Orange(), vehical.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);
                    esp.DrawText(FEColor::Alien(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);

                }

                if ((strstr(vehical.Name, "Bike") && isBike) ||
                    (strstr(vehical.Name, "Trike") && istrick) ||
                    (strstr(vehical.Name, "Tuk Tuk") && isTukTuk) ||
                        (strstr(vehical.Name, "Motor Glider") && ismotarglider) ||(strstr(vehical.Name, "Ferris Car") && isFerrisCar)) {
                    esp.DrawText(FEColor::Orange(), vehical.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);
                    esp.DrawText(FEColor::Alien(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);

                }
                if ((strstr(vehical.Name, "SnowBike") && issnowbike) ||
                    (strstr(vehical.Name, "SnowMobile") && issnowmobile) ||
                    (strstr(vehical.Name, "BRDM") && isBRDM)) {
                    esp.DrawText(FEColor::Orange(), vehical.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);
                    esp.DrawText(FEColor::Alien(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);

                }
                if ((strstr(vehical.Name, "AquaRail") && isjet) ||
                    (strstr(vehical.Name, "Boat") && isBoat)) {
                    esp.DrawText(FEColor::Orange(), vehical.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);
                    esp.DrawText(FEColor::Alien(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);

                }
                if (
                        (strstr(vehical.Name, "AirDrop") && Airdrop) ||
                        (strstr(vehical.Name, "AirDropPlane") && DropPlane) ||
                        (strstr(vehical.Name, "Crate") && Crate)) {
                    esp.DrawText(FEColor::Crimson(), vehical.Name, FEVector2(
                            location.x, location.y + (20 * mScale)), itemTextSize);

                    esp.DrawText(FEColor::White(), dist.c_str(), FEVector2(
                            location.x, location.y + (40 * mScale)), itemTextSize);
                }
//                            if (strstr(vehical.Name, "Truck") && isMonstertruck) {
//                                esp.DrawText(FEColor::Orange(), vehical.Name, FEVector2(
//                                        location.x, location.y + (20 * mScale)), itemTextSize);
//                                esp.DrawText(FEColor::Green(), dist.c_str(), FEVector2(
//                                        location.x, location.y + (40 * mScale)), itemTextSize);
//                            }
            }


        }
    }
}


#endif //HACKS_H
