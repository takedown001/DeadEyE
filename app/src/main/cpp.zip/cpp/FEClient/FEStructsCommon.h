#ifndef FESTRUCTSCOMM_H
#define FESTRUCTSCOMM_H

#include "FEVector3.h"
#include "FEVector2.h"
#include "FERect.h"

using namespace std;

#define maxplayerCount 30
#define maxitemsCount 40
#define maxvehicalCount 40
enum Mode {
	InitMode = 1,
	ESPMode = 2,
	HackMode = 3,
	StopMode = 4,
};

struct Request {
	int Mode;
	int ScreenWidth;
	int ScreenHeight;
};

struct PlayerData {
	wchar_t PlayerName[30];
	bool isBot;
	int TeamID;
//	int PlayerID;
	float Health;
	float Distance;
	FEVector2 Body;
	FEVector2 Root;
	FEVector2 Head;
	FEVector2 Neck;
	FEVector2 Chest;
	FEVector2 Pelvis;
	FEVector2 LShoulder;
	FEVector2 RShoulder;
	FEVector2 LElbow;
	FEVector2 RElbow;
	FEVector2 LWrist;
	FEVector2 RWrist;
	FEVector2 LThigh;
	FEVector2 RThigh;
	FEVector2 LKnee;
	FEVector2 RKnee;
	FEVector2 LAnkle;
	FEVector2 RAnkle;
};
struct VehicalData{
	char Name[20];
	float Distance;
	FEVector2 Location;
};
struct ItemData {
	char Name[20];
	bool isVehicle;
	bool isLootBox;
	bool isAirDrop;
	bool isLootItem;
	float Distance;
	FEVector2 Location;
};

struct Response {
    bool Success;
    int NearEnemy;
    int MyTeamID;
    int PlayerCount;
    int ItemsCount;
    int VehicalCount;
    VehicalData Vehical[maxvehicalCount];
    PlayerData Players[maxplayerCount];
    ItemData Items[maxitemsCount];
};

#endif
