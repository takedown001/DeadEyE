#ifndef FEVECTOR2_H
#define FEVECTOR2_H

class FEVector2 {
public:
    float x;
    float y;

    FEVector2() {
        Init();
    }

    FEVector2(float X, float Y) {
        Init(X, Y);
    }

    void Init(float ix = 0.0f, float iy = 0.0f) {
        x = ix;
        y = iy;
    }

    static FEVector2 Zero() {
        return FEVector2(0.0f, 0.0f);
    }

    static FEVector2 Up() {
        return FEVector2(0.0f, 1.0f);
    }

    static FEVector2 Down() {
        return FEVector2(0.0f, -1.0f);
    }

    static FEVector2 Back() {
        return FEVector2(0.0f, 0.0f);
    }

    static FEVector2 Forward() {
        return FEVector2(0.0f, 0.0f);
    }

    static FEVector2 Left() {
        return FEVector2(-1.0f, 0.0f);
    }

    static FEVector2 Right() {
        return FEVector2(1.0f, 0.0f);
    }

    float &operator[](int i) {
        return ((float *) this)[i];
    }

    float operator[](int i) const {
        return ((float *) this)[i];
    }

    bool operator==(const FEVector2 &src) const {
        return (src.x == x) && (src.y == y);
    }

    bool operator!=(const FEVector2 &src) const {
        return (src.x != x) || (src.y != y);
    }

    FEVector2 &operator+=(const FEVector2 &v) {
        x += v.x;
        y += v.y;
        return *this;
    }

    FEVector2 &operator-=(const FEVector2 &v) {
        x -= v.x;
        y -= v.y;
        return *this;
    }

    FEVector2 &operator*=(float fl) {
        x *= fl;
        y *= fl;
        return *this;
    }

    FEVector2 &operator*=(const FEVector2 &v) {
        x *= v.x;
        y *= v.y;
        return *this;
    }

    FEVector2 &operator/=(const FEVector2 &v) {
        x /= v.x;
        y /= v.y;
        return *this;
    }

    FEVector2 &operator+=(float fl) {
        x += fl;
        y += fl;
        return *this;
    }

    FEVector2 &operator/=(float fl) {
        x /= fl;
        y /= fl;
        return *this;
    }

    FEVector2 &operator-=(float fl) {
        x -= fl;
        y -= fl;
        return *this;
    }

    FEVector2 &operator=(const FEVector2 &vOther) {
        x = vOther.x;
        y = vOther.y;
        return *this;
    }

    FEVector2 operator-(void) const {
        return FEVector2(-x, -y);
    }

    FEVector2 operator+(const FEVector2 &v) const {
        return FEVector2(x + v.x, y + v.y);
    }

    FEVector2 operator-(const FEVector2 &v) const {
        return FEVector2(x - v.x, y - v.y);
    }

    FEVector2 operator*(float fl) const {
        return FEVector2(x * fl, y * fl);
    }

    FEVector2 operator*(const FEVector2 &v) const {
        return FEVector2(x * v.x, y * v.y);
    }

    FEVector2 operator/(float fl) const {
        return FEVector2(x / fl, y / fl);
    }

    FEVector2 operator/(const FEVector2 &v) const {
        return FEVector2(x / v.x, y / v.y);
    }
};

#endif
