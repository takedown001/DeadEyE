#ifndef VECTOR3_H
#define VECTOR3_H

class FEVector3 {
public:
    float x;
    float y;
    float z;

    FEVector3() {
        this->x = 0;
        this->y = 0;
        this->z = 0;
    }

    FEVector3(float x, float y, float z) {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    FEVector3(float x, float y) {
        this->x = x;
        this->y = y;
        this->z = 0;
    }

    static FEVector3 Zero() {
        return FEVector3(0.0f, 0.0f, 0.0f);
    }

    static FEVector3 Up() {
        return FEVector3(0.0f, 1.0f, 0.0f);
    }

    static FEVector3 Down() {
        return FEVector3(0.0f, -1.0f, 0.0f);
    }

    static FEVector3 Back() {
        return FEVector3(0.0f, 0.0f, -1.0f);
    }

    static FEVector3 Forward() {
        return FEVector3(0.0f, 0.0f, 1.0f);
    }

    static FEVector3 Left() {
        return FEVector3(-1.0f, 0.0f, 0.0f);
    }

    static FEVector3 Right() {
        return FEVector3(1.0f, 0.0f, 0.0f);
    }

    float &operator[](int i) {
        return ((float *) this)[i];
    }

    float operator[](int i) const {
        return ((float *) this)[i];
    }

    bool operator==(const FEVector3 &src) const {
        return (src.x == x) && (src.y == y) && (src.z == z);
    }

    bool operator!=(const FEVector3 &src) const {
        return (src.x != x) || (src.y != y) || (src.z != z);
    }

    FEVector3 &operator+=(const FEVector3 &v) {
        x += v.x;
        y += v.y;
        z += v.z;
        return *this;
    }

    FEVector3 &operator-=(const FEVector3 &v) {
        x -= v.x;
        y -= v.y;
        z -= v.z;
        return *this;
    }

    FEVector3 &operator*=(float fl) {
        x *= fl;
        y *= fl;
        z *= fl;
        return *this;
    }

    FEVector3 &operator*=(const FEVector3 &v) {
        x *= v.x;
        y *= v.y;
        z *= v.z;
        return *this;
    }

    FEVector3 &operator/=(const FEVector3 &v) {
        x /= v.x;
        y /= v.y;
        z /= v.z;
        return *this;
    }

    FEVector3 &operator+=(float fl) {
        x += fl;
        y += fl;
        z += fl;
        return *this;
    }

    FEVector3 &operator/=(float fl) {
        x /= fl;
        y /= fl;
        z /= fl;
        return *this;
    }

    FEVector3 &operator-=(float fl) {
        x -= fl;
        y -= fl;
        z -= fl;
        return *this;
    }

    FEVector3 &operator=(const FEVector3 &vOther) {
        x = vOther.x;
        y = vOther.y;
        z = vOther.z;
        return *this;
    }

    FEVector3 operator-(void) const {
        return FEVector3(-x, -y, -z);
    }

    FEVector3 operator+(const FEVector3 &v) const {
        return FEVector3(x + v.x, y + v.y, z + v.z);
    }

    FEVector3 operator-(const FEVector3 &v) const {
        return FEVector3(x - v.x, y - v.y, z - v.z);
    }

    FEVector3 operator*(float fl) const {
        return FEVector3(x * fl, y * fl, z * fl);
    }

    FEVector3 operator*(const FEVector3 &v) const {
        return FEVector3(x * v.x, y * v.y, z * v.z);
    }

    FEVector3 operator/(float fl) const {
        return FEVector3(x / fl, y / fl, z / fl);
    }

    FEVector3 operator/(const FEVector3 &v) const {
        return FEVector3(x / v.x, y / v.y, z / v.z);
    }

    static float Distance(FEVector3 a, FEVector3 b) {
        FEVector3 vector = FEVector3(a.x - b.x, a.y - b.y, a.z - b.z);
        return sqrt(((vector.x * vector.x) + (vector.y * vector.y)) + (vector.z * vector.z));
    }

    static float Dot(FEVector3 lhs, FEVector3 rhs) {
        return (((lhs.x * rhs.x) + (lhs.y * rhs.y)) + (lhs.z * rhs.z));
    }

    float sqrMagnitude() const {
        return (x * x + y * y + z * z);
    }
};

#endif
