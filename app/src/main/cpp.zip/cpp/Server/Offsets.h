#ifndef OFFSETS_H
#define OFFSETS_H

namespace Offsets {
    enum Offsets {
		//Global
		GWorld = 0x4C7F360,
		GNames = 0x4EE2604,
		PointerSize = 0x4,

		//Struct Size
		FTransformSizeInGame = 0x30,

		//---------SDK-----------
		//Class: FNameEntry
		FNameEntryToNameString = 0x8,
		//Class: UObject
		UObjectToInternalIndex = 0x8,
		UObjectToFNameIndex = 0x10,

		//---------PUBG UEClasses-----------
		//Class: World
		WorldToPersistentLevel = 0x20,
		//Class: Level
		LevelToAActors = 0x70,
		//Class: PlayerController
		UAEPlayerControllerToPlayerKey = 0x594,
		UAEPlayerControllerToTeamID =  0x5AC,
		//Class: PlayerCameraManager
		PlayerCameraManagerToCameraCacheEntry = 0x330,
		//Class: CameraCacheEntry
		CameraCacheEntryToMinimalViewInfo = 0x10,
		//Class: SceneComponent
		SceneComponentToComponentToWorld = 0x140,
		//Class: SkeletalMeshComponent
		SkeletalMeshComponentToCachedComponentSpaceTransforms = 0x66C,
		//Class: Actor
		ActorToRootComponent = 0x140,
		//Class: Character
		CharacterToMesh = 0x30C,
		//Class: UAECharacter
		UAECharacterToPlayerName = 0x5F8,
		UAECharacterToPlayerKey = 0x610,
		UAECharacterToTeamID = 0x620,
		UAECharacterTobIsAI = 0x688,
		//Class: STExtraCharacter
		STExtraCharacterToHealth = 0x7A0,

    };
}

#endif
